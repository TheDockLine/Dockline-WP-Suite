<?php

/**
 * Fired during plugin activation
 *
 * @link       https://thedockline.com
 * @since      1.0.0
 *
 * @package    Dockline_Wp_Suite
 * @subpackage Dockline_Wp_Suite/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Dockline_Wp_Suite
 * @subpackage Dockline_Wp_Suite/includes
 * @author     Levi <levi@thedockline.com>
 */
class Dockline_Wp_Suite_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
